function binaryImage = drawCircularComponents(circulars, imageSize)
    % DRAWCIRCULARCOMPONENTS crea una imagen binaria representando los 
    % componentes circulares.
    %
    % Esta función toma una lista de componentes circulares y el tamaño 
    % de la imagen original, y devuelve una imagen binaria donde cada 
    % píxel perteneciente a un componente circular se marca en blanco 
    % (255), mientras que el resto de los píxeles se mantienen en negro (0).
    %
    % Parámetros:
    %   circulars: Una celda de estructuras, donde cada estructura 
    % representa un componente circular detectado en la imagen original. 
    % Cada estructura contiene un campo 'points', que es una matriz Nx2 
    % de coordenadas de píxeles pertenecientes al componente.
    %   imageSize: Un vector de 2 elementos [numRows, numCols] que 
    % especifica el tamaño de la imagen binaria a crear.
    %
    % Devoluciones:
    %   binaryImage: Una imagen binaria del tamaño especificado, con los 
    % componentes circulares dibujados en blanco.
    %
    % La función inicializa una imagen binaria con ceros (negro) y luego 
    % itera a través de cada componente en 'circulars'. Para cada 
    % componente, coloca píxeles blancos en las coordenadas
    % correspondientes a los puntos del componente en la imagen binaria.

    % Inicializar una imagen binaria vacía del tamaño especificado
    % Crear una imagen binaria vacía
    binaryImage = zeros(imageSize);

    % Dibujar cada componente circular en la imagen
    for i = 1:length(circulars)
        component = circulars{i};
        for j = 1:size(component.points, 1)
            point = component.points(j, :);
            binaryImage(point(1), point(2)) = 255; % Coloca un píxel blanco
        end
    end
end