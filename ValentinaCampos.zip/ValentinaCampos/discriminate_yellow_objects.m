function binary_image = discriminate_yellow_objects(rgb_image)
    % DISCRIMINATE_YELLOW_OBJECTS convierte una imagen RGB en una imagen
    % binaria donde todos los objetos amarillos pasan a ser blancos y el
    % resto a negro.
    % La función utiliza el espacio de color HSV para una mejor
    % discriminación del color amarillo. Se aplica un umbral para
    % seleccionar los píxeles amarillos y luego se utilizan operaciones 
    % morfológicas para eliminar el ruido y mejorar la selección de los 
    % objetos amarillos.
    %
    % Parámetros:
    %   rgb_image: Una imagen en formato RGB (matriz MxNx3).
    %
    % Devoluciones:
    %   binary_image: Una imagen binaria (matriz MxN) donde los píxeles que 
    %                 corresponden a objetos amarillos en la imagen original tienen
    %                 un valor de 255 y todos los demás píxeles tienen un valor de 0.
    %
    % Se convierte la imagen de entrada de RGB a HSV para facilitar la 
    % discriminación de los objetos basados en su color.
    hsv_image = rgb2hsv(rgb_image);

    % Se definen los umbrales para el color amarillo en HSV
    hue_min = 1/12 - 0.0000001;
    hue_max = 1/12 + 0.1;
    saturation_min = 0.3;
    value_min = 0.001;

    % Se crea la máscara binaria para los píxeles amarillos
    yellow_mask = (hsv_image(:,:,1) >= hue_min) & (hsv_image(:,:,1) <= hue_max) ...
        & (hsv_image(:,:,2) >= saturation_min) ...
        & (hsv_image(:,:,3) >= value_min);

    % Post-procesamiento para eliminar puntos dispersos
    % Definir el elemento estructurante para la erosión y la dilatación
    se = strel('disk', 9); 
    se2 = strel('disk', 21);
    
    % Se erosiona la imagen para deshacerse de los pequeños puntos
    eroded_mask = imerode(yellow_mask, se);
    
    % Se dilata la imagen para restaurar la forma de los objetos amarillos
    binary_image = imdilate(eroded_mask, se2);

    % Se convierte la máscara final a una imagen binaria con valores de 0 o
    % 255.
    binary_image = uint8(binary_image) * 255;
end