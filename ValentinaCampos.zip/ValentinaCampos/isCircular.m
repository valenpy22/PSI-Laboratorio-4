function [cantidadCirculares, circulars] = isCircular(component_list)
    % ISCIRCULAR evalúa los componentes de una imagen para determinar si 
    % son circulares.
    %
    % Esta función recorre una lista de componentes, calcula el ratio de 
    % circularidad de cada uno, y selecciona aquellos que se consideran 
    % circulares basándose en un umbral predefinido.
    %
    % Parámetros:
    %   component_list: Una lista de componentes detectados en la imagen. 
    % Cada componente es una estructura que incluye, entre otros, los 
    % campos 'area' y 'perimeter', que representan el área y el perímetro 
    % del componente, respectivamente.
    %
    % Devoluciones:
    %   cantidadCirculares: Un entero que indica la cantidad de componentes 
    % circulares encontrados.
    %   circulars: Una celda que contiene las estructuras de los 
    % componentes que se han identificado como circulares.
    %
    % El ratio de circularidad se calcula como 
    % (perímetro^2) / (4 * pi * área). Un círculo perfecto tiene un ratio 
    % de circularidad de 1. La función utiliza un umbral (en este caso 0.7) 
    % para decidir si un componente es suficientemente circular. 
    % Los componentes que tienen un ratio de
    % circularidad cercano a 1 (dentro del umbral) se consideran circulares.

    % Inicialización de las variables de salida
    circulars = {};
    cantidadCirculares = 0;

    % Se itera sobre cada componente en la lista
    for i = 1:length(component_list)
        component = component_list{i};
        % Se calcula el ratio de circularidad
        circularity_ratio = (component.perimeter^2) / (4 * pi * component.area);
        
        % Se verifica si el componente es circular según el umbral
        if abs(circularity_ratio - 1) < 0.7
            % Se agrega el componente a la lista de circulares
            cantidadCirculares = cantidadCirculares + 1;
            circulars{cantidadCirculares} = component;
        end
    end
end
