function [binary_image, component, visited] = bfs(binary_image, visited, start_i, start_j, component_id)
    % BFS realiza una búsqueda en anchura en una imagen binaria para
    % identificar y segmentar un componente conectado basado en un punto de
    % inicio dado.
    % La función actualiza la imagen binaria con un identificador de componente único y calcula
    % el área, el perímetro y el bounding box del componente.
    %
    % Parámetros:
    %   binary_image: Una matriz binaria donde los píxeles del componente están marcados con 255 y
    %                 el fondo con 0.
    %   visited: Una matriz lógica del mismo tamaño que 'binary_image', donde los píxeles ya visitados
    %            están marcados como true.
    %   start_i: El índice de la fila del píxel de inicio para la búsqueda.
    %   start_j: El índice de la columna del píxel de inicio para la búsqueda.
    %   component_id: Un identificador numérico único para el componente actual.
    %
    % Devoluciones:
    %   binary_image: La imagen binaria actualizada con el 'component_id' reemplazando los valores de 255
    %                 en los píxeles del componente detectado.
    %   component: Una estructura con la siguiente información sobre el componente detectado:
    %      - points: Un arreglo de coordenadas de píxeles que pertenecen al componente.
    %      - border: Un arreglo de coordenadas de píxeles que están en el borde del componente.
    %      - bbox: Un vector con cuatro elementos [min_x, min_y, width, height] que definen el
    %              bounding box del componente.
    %      - area: Un escalar que representa el número total de píxeles en el componente.
    %      - perimeter: Un escalar que representa el número total de píxeles en el borde del componente.
    %   visited: La matriz 'visited' actualizada.
    
    % Inicialización de la cola para realizar la búsqueda en anchura
    queue = [start_i, start_j];
    component.points = [];
    component.border = [];
    component.bbox = [inf, inf, -inf, -inf]; % [min_x, min_y, max_x, max_y]
    [rows, cols] = size(binary_image);
    component.area = 0;
    component.perimeter = 0;

    % Bucle principal que permite hacer la búsqueda en anchura
    while ~isempty(queue)
        [i, j] = deal(queue(1,1), queue(1,2)); % Se obtiene el primer pixel de la cola
        queue(1,:) = []; % Se retira el pixel de la cola

        % Si el pixel ya fue visitado, se salta al siguiente pixel.
        if visited(i,j)
            continue;
        end

        % De lo contrario, se marca como visitado y como parte del
        % componente actual
        visited(i,j) = true;
        binary_image(i,j) = component_id;
        component.points(end+1,:) = [i, j]; % Se agrega el pixel a los puntos del componente
        
        % Se verifica si el pixel es parte del borde y se actualiza el
        % bounding box
        is_border_pixel = false;
        for di = -1:1
            for dj = -1:1
                ni = i + di; % Nueva coordenada de fila
                nj = j + dj; % Nueva coordenada de columna
                
                % Se comprueban los límites y si el pixel es parte del
                % componente
                if ni < 1 || ni > rows || nj < 1 || nj > cols || binary_image(ni, nj) == 0
                    is_border_pixel = true;
                else
                    if ~visited(ni, nj) && binary_image(ni, nj) == 255
                        queue(end+1,:) = [ni, nj]; % Se agrega pixel vecino a la cola
                    end
                end
            end
        end

        % Se incrementa el área del componente
        component.area = component.area + 1;

  
        % Si el pixel es borde, se actualiza la lista de bordes y el
        % perímetro
        if is_border_pixel
            component.border(end+1,:) = [i, j];
            component.perimeter = component.perimeter + 1;
        end

        % Se actualiza el bounding box
        component.bbox = [min(component.bbox(1), j), min(component.bbox(2), i), ...
                          max(component.bbox(3), j), max(component.bbox(4), i)];
    end

    % Se convierte el bounding box a formato [x, y, ancho, alto]
    component.bbox = [component.bbox(1:2), component.bbox(3:4) - component.bbox(1:2) + 1];
end
