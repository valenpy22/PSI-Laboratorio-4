function writeComponentInfoToFile(component_list, filename)
    % WRITECOMPONENTINFOTOFILE escribe en un archivo de texto la información de cada componente 
    % detectado en la imagen.
    %
    % Esta función toma una lista de componentes y un nombre de archivo, y escribe en el archivo
    % un resumen de las propiedades de cada componente, incluyendo su área, perímetro, bounding box,
    % centroid y circularidad. El archivo de salida tiene un formato de tabla para facilitar su lectura.
    %
    % Parámetros:
    %   component_list: Una lista de componentes detectados en la imagen. Cada componente es una estructura
    %                   que contiene información sobre el área, perímetro, bounding box, y los puntos
    %                   que conforman el componente.
    %   filename: El nombre del archivo de texto donde se escribirá la información.
    %
    % Cada fila en el archivo de salida representa un componente, con las siguientes columnas:
    %   ComponentID: Un identificador numérico asignado al componente.
    %   Area: El área del componente en píxeles.
    %   Perimeter: El perímetro del componente en píxeles.
    %   BoundingBox: Las coordenadas del bounding box del componente en formato [x, y, width, height].
    %   CentroidX, CentroidY: Las coordenadas del centroide del componente.
    %   Circularity: Un valor que mide la circularidad del componente, donde 1 es un círculo perfecto.

    % Abrir el archivo para escritura
    fileID = fopen(filename, 'w');

    % Escribir los encabezados de las columnas en el archivo
    fprintf(fileID, '%s\t%s\t%s\t%s\t%s\t%s\t%s\n', 'ComponentID', 'Area', 'Perimeter', 'BoundingBox', 'CentroidX', 'CentroidY', 'Circularity');
    
    % Iterar sobre cada componente en la lista y escribir su información
    for i = 1:length(component_list)
        component = component_list{i};
        % Calcular el centroide y la circularidad del componente
        centroid = mean(component.points, 1);
        circularity = (component.perimeter^2) / (4 * pi * component.area);
        
        % Escribir la información del componente en el archivo
        fprintf(fileID, '%d\t%d\t%d\t[%d, %d, %d, %d]\t%f\t%f\t%f\n', ...
                i, component.area, component.perimeter, ...
                component.bbox(1), component.bbox(2), component.bbox(3), component.bbox(4), ...
                centroid(1), centroid(2), circularity);
    end
    
    % Cerrar el archivo de texto
    fclose(fileID);
end
