function [border_image, component_list] = detect_components(binary_image)
    % DETECT_COMPONENTS realiza una segmentación de componentes conectados
    % en una imagen binaria.
    % Se realiza una búsqueda por anchura para explorar y etiquetar los
    % componentes.
    % Además, identifica los píxeles que forman el borde de cada
    % componente.
    %
    % Parámetros:
    %   binary_image: Una matriz binaria (2D) donde los píxeles de los objetos tienen un valor de 255 y
    %                 el fondo tiene un valor de 0.
    %
    % Devoluciones:
    %   border_image: Una matriz binaria (2D) del mismo tamaño que 'binary_image' donde sólo los píxeles
    %                 que forman el borde de cada componente están marcados con 255.
    %   component_list: Una celda donde cada elemento es una estructura que representa un componente
    %                   conectado. La estructura contiene los siguientes campos:
    %                   - points: Un arreglo Nx2 de [fila, columna] de píxeles pertenecientes al componente.
    %                   - border: Un arreglo Nx2 de [fila, columna] de píxeles del borde del componente.
    %                   - bbox: Un vector de 4 elementos [min_x, min_y, ancho, alto] que representa
    %                           el cuadro delimitador del componente.
    %                   - area: Un escalar que indica el número total de píxeles en el componente.
    %                   - perimeter: Un escalar que indica el número total de píxeles en el borde del componente.
    %                   - id: El identificador numérico único asignado al componente.
    %
    % La función recorre la imagen binaria y cuando encuentra un píxel blanco no visitado, comienza
    % una búsqueda en anchura desde ese píxel para identificar todos los píxeles conectados que forman
    % un componente. También detecta los píxeles de borde del componente durante la búsqueda.
    % Finalmente, actualiza la imagen de bordes y la lista de componentes con la información recopilada.
    
    % Se inicializan variables
    [rows, cols] = size(binary_image);
    visited = false(rows, cols);
    component_id = 0;
    component_list = {};
    border_image = zeros(rows, cols, 'uint8'); % Imagen para los bordes de todos los componentes.
    
    % Se realiza un bucle para recorrer cada pixel de la imagen
    for i = 1:rows
        for j = 1:cols
            % Se verifica si el pixel actual es parte de un componente y
            % aún no ha sido visitado
            if binary_image(i,j) == 255 && ~visited(i,j)
                % Se le asigna un nuevo ID al componente
                component_id = component_id + 1;

                % Se llama a BFS y se obtiene la información
                [binary_image, component, visited] = bfs(binary_image, visited, i, j, component_id);

                % Se actualiza la lista de componentes
                component_list{component_id} = component;
            end
        end
    end
end