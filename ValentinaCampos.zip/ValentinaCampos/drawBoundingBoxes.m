function final_image = drawBoundingBoxes(originalImage, component_list)
    % DRAWBOUNDINGBOXES dibuja rectángulos delimitadores alrededor de los
    % componentes detectados en una imagen y devuelve la imagen resultante.
    % 
    % Esta función toma una imagen original y una lista de componentes detectados, y
    % dibuja un rectángulo delimitador alrededor de cada componente en la imagen.
    % Los rectángulos se dibujan en un color específico (rojo) y con un grosor de línea determinado.
    %
    % Parámetros:
    %   originalImage: La imagen original (en color o en escala de grises) en la que se
    %                  dibujarán los rectángulos delimitadores.
    %   component_list: Una lista de componentes detectados. Cada componente es una estructura
    %                   que contiene, entre otros, el campo 'bbox' que especifica el
    %                   bounding box del componente en formato [x, y, width, height].
    %
    % Devoluciones:
    %   final_image: Una copia de la imagen original con los rectángulos delimitadores
    %                dibujados sobre ella.
    %
    % La función crea una nueva figura, dibuja los rectángulos en los componentes
    % especificados y luego captura el resultado como una imagen. Esta imagen se
    % devuelve y la figura se cierra para no dejar residuos en la interfaz gráfica de usuario.

    % Crear una copia de la imagen original para dibujar sobre ella
    final_image = originalImage;

    % Se crea una nueva figura y se muestra la imagen
    figure;
    imshow(final_image);
    hold on;
    
    % Iterar sobre cada componente y dibujar su bounding box
    for i = 1:length(component_list)
        component = component_list{i};
        bbox = component.bbox; % bbox es [x, y, width, height]

        % Dibujar un rectángulo alrededor del componente
        rectangle('Position', bbox, 'EdgeColor', 'r', 'LineWidth', 2);
    end

    % Se finaliza el dibujo y se captura la imagen de los ejes
    hold off;
    drawnow;

    frame = getframe(gca);
    final_image = frame.cdata; % Se extrae la imagen de la figura
    
    % Se cierra
    close;
end